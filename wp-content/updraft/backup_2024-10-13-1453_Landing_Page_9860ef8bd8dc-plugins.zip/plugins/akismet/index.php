<?php
# Silence is golden.